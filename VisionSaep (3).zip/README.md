# SAEPVision

Projeto desenvolvido com base no enunciado da avaliação prática SAEP/SENAI.

## Tecnologias
- HTML, CSS e JavaScript no frontend
- Node.js + Express no backend
- MySQL para persistência dos dados
- bcryptjs para armazenar senhas com hash
- Multer para upload de imagens

## Como executar
1. Instale Node.js e MySQL.
2. Abra o MySQL Workbench e execute `database/saepvision.sql`.
3. Abra esta pasta no VS Code e execute `npm install`.
4. Copie `.env.example` para `.env` e ajuste usuário/senha do MySQL.
5. Execute `npm start`.
6. Acesse `http://localhost:3000`.

## Fluxo de uso
- Crie uma conta escolhendo usuário comum ou fotógrafo.
- Usuários fotógrafos podem cadastrar publicações com título, local e imagem.
- Usuários autenticados podem curtir e descurtir cada publicação.
- A busca filtra publicações pelo nome do fotógrafo.
- O menu de perfil mostra o total de publicações e curtidas.

## Banco de dados
O arquivo `database/saepvision.sql` cria as tabelas `usuarios`, `publicacoes` e `curtidas`, com chaves estrangeiras e restrição para impedir curtidas duplicadas.

## Observações
- O enunciado menciona a importação de `usuarios.csv`, mas esse CSV não foi fornecido junto com a prova. Por isso, não foram inventados registros ou colunas para ele.
- A aplicação usa sessão local para autenticação. Para publicação em produção, configure HTTPS, segredo de sessão forte e armazenamento de sessão persistente.
- Os arquivos enviados ficam em `public/uploads`.
