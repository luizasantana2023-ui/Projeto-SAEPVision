const $ = s => document.querySelector(s);
let usuario = null;
const modal = $('#modal');
function abrirModal(registro=false){modal.classList.add('aberto');$('#loginForm').hidden=registro;$('#registroForm').hidden=!registro;$('#modalTitulo').textContent=registro?'Cadastro':'Login';}
function fecharModal(){modal.classList.remove('aberto');}
$('#loginBtn').onclick=()=>usuario?$('#lateral').classList.add('aberto'):abrirModal();
$('#perfilBtn').onclick=()=>usuario?$('#lateral').classList.add('aberto'):abrirModal();
$('#fechar').onclick=fecharModal;modal.onclick=e=>{if(e.target===modal)fecharModal()};
$('#irRegistro').onclick=e=>{e.preventDefault();abrirModal(true)};
$('#irLogin').onclick=e=>{e.preventDefault();abrirModal(false)};
$('#fecharLateral').onclick=()=>$('#lateral').classList.remove('aberto');

async function api(url, options={}) {
  const r=await fetch(url,options); const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.erro||'Ocorreu um erro.'); return data;
}
function atualizarTopo(){
  $('#usuarioArea').querySelector('strong').textContent=usuario?.nome||'Visitante';
  $('#usuarioArea').querySelector('small').textContent=usuario?'@'+usuario.tipo:'@SAEPVision';
  $('#usuarioArea .avatar').textContent=usuario?.nome?.[0]?.toUpperCase()||'?';
  $('#loginBtn').textContent=usuario?'Menu':'Login';
  $('#cadastro').hidden=!(usuario&&usuario.tipo==='fotografo');
}
async function carregarFotos(filtro=''){
  const galeria=$('#galeria');galeria.innerHTML='<p class="carregando">Carregando fotografias...</p>';
  try{
    const fotos=await api('/api/fotos'+(filtro?'?fotografo='+encodeURIComponent(filtro):''));
    galeria.innerHTML='';
    if(!fotos.length){galeria.innerHTML='<p class="carregando">Nenhuma fotografia encontrada.</p>';return;}
    fotos.forEach(f=>{
      const card=document.createElement('article');card.className='foto';
      const img=document.createElement('img');img.src=f.imagem;img.alt=f.titulo;
      const info=document.createElement('div');info.className='fotoInfo';
      const title=document.createElement('strong');title.textContent=f.titulo;
      const local=document.createElement('small');local.textContent='Local: '+f.local_foto;
      const author=document.createElement('small');author.textContent='Foto tirada por: @'+f.fotografo;
      const like=document.createElement('button');like.className='curtir'+(f.curtida_por_mim?' ativo':'');like.textContent=(f.curtida_por_mim?'♥':'♡')+' '+f.curtidas;
      like.title='Curtir fotografia';
      like.onclick=async()=>{if(!usuario){abrirModal();return;}try{const r=await api(`/api/fotos/${f.id}/curtir`,{method:'POST'});like.classList.toggle('ativo',r.curtido);like.textContent=(r.curtido?'♥':'♡')+' '+r.total;}catch(e){alert(e.message)}};
      info.append(title,local,author,like);card.append(img,info);galeria.append(card);
    });
  }catch(e){galeria.innerHTML='<p class="carregando">'+e.message+'</p>';}
}
$('#buscaForm').onsubmit=e=>{e.preventDefault();carregarFotos($('#busca').value.trim())};
$('#loginForm').onsubmit=async e=>{
  e.preventDefault();const fd=new FormData(e.target);
  try{const d=await api('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(fd))});usuario=d.usuario;fecharModal();atualizarTopo();carregarFotos();}
  catch(err){$('#loginErro').textContent=err.message;}
};
$('#registroForm').onsubmit=async e=>{
  e.preventDefault();const fd=new FormData(e.target);
  try{const d=await api('/api/registro',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(fd))});usuario=d.usuario;fecharModal();atualizarTopo();carregarFotos();}
  catch(err){$('#registroErro').textContent=err.message;}
};
$('#fotoForm').onsubmit=async e=>{
  e.preventDefault();try{await api('/api/fotos',{method:'POST',body:new FormData(e.target)});e.target.reset();alert('Fotografia cadastrada!');carregarFotos();}
  catch(err){alert(err.message);}
};
$('#logoutBtn').onclick=async()=>{await api('/api/logout',{method:'POST'});usuario=null;$('#lateral').classList.remove('aberto');atualizarTopo();carregarFotos();};
$('#minhasFotos').onclick=async()=>{
  if(!usuario)return;
  try{
    const p=await api('/api/usuarios/'+usuario.id);
    $('#perfilNome').textContent=p.nome;
    $('#perfilDados').textContent=`${p.curtidas} curtidas · ${p.publicacoes} publicações`;
    $('#lateral').classList.remove('aberto');
    $('#busca').value=p.nome;carregarFotos(p.nome);
  }catch(e){alert(e.message)}
};
(async()=>{usuario=await api('/api/me').catch(()=>null);atualizarTopo();carregarFotos();})();
