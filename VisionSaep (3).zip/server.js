const express = require('express');
const session = require('express-session');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'saepvision',
  waitForConnections: true, connectionLimit: 10
});

const uploadDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_'))
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => cb(null, /\.(jpe?g|png|gif|webp)$/i.test(file.originalname))
});

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'saepvision-chave-local',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax' }
}));
app.use(express.static(path.join(__dirname, 'public')));

function page(file) { return path.join(__dirname, 'public', file); }
function logged(req, res, next) {
  if (!req.session.user) return res.status(401).json({ erro: 'Faça login para continuar.' });
  next();
}
function safeUser(u) {
  return { id: u.id, nome: u.nome, email: u.email, tipo: u.tipo, foto_perfil: u.foto_perfil };
}

app.get('/', (_, res) => res.sendFile(page('index.html')));
app.get('/api/me', (req, res) => res.json(req.session.user || null));

app.get('/api/fotos', async (req, res) => {
  try {
    const params = [];
    let where = '';
    if (req.query.fotografo) {
      where = 'WHERE u.nome LIKE ?';
      params.push('%' + req.query.fotografo.replace(/^@/, '') + '%');
    }
    const [rows] = await pool.query(`
      SELECT p.id, p.titulo, p.local_foto, p.imagem, p.criado_em,
             u.id AS usuario_id, u.nome AS fotografo, u.foto_perfil,
             COUNT(c.id) AS curtidas,
             MAX(CASE WHEN c.usuario_id = ? THEN 1 ELSE 0 END) AS curtida_por_mim
      FROM publicacoes p
      JOIN usuarios u ON u.id = p.usuario_id
      LEFT JOIN curtidas c ON c.publicacao_id = p.id
      ${where}
      GROUP BY p.id ORDER BY p.criado_em DESC`, [req.session.user?.id || 0, ...params]);
    res.json(rows);
  } catch (e) { res.status(500).json({ erro: 'Não foi possível carregar as fotografias.' }); }
});

app.post('/api/registro', async (req, res) => {
  try {
    const { nome, email, senha, tipo } = req.body;
    if (!nome || !email || !senha || senha.length < 6) return res.status(400).json({ erro: 'Preencha todos os campos. A senha deve ter ao menos 6 caracteres.' });
    const hash = await bcrypt.hash(senha, 10);
    const [r] = await pool.execute('INSERT INTO usuarios (nome,email,senha,tipo) VALUES (?,?,?,?)',
      [nome.trim(), email.trim().toLowerCase(), hash, tipo === 'fotografo' ? 'fotografo' : 'comum']);
    const user = { id: r.insertId, nome: nome.trim(), email: email.trim().toLowerCase(), tipo: tipo === 'fotografo' ? 'fotografo' : 'comum' };
    req.session.user = user;
    res.json({ usuario: user });
  } catch (e) { res.status(400).json({ erro: e.code === 'ER_DUP_ENTRY' ? 'Este e-mail já está cadastrado.' : 'Erro ao criar conta.' }); }
});

app.post('/api/login', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM usuarios WHERE email = ?', [String(req.body.email || '').toLowerCase()]);
    if (!rows.length || !(await bcrypt.compare(req.body.senha || '', rows[0].senha)))
      return res.status(401).json({ erro: 'Usuário não encontrado ou senha incorreta.' });
    req.session.user = safeUser(rows[0]);
    res.json({ usuario: req.session.user });
  } catch (e) { res.status(500).json({ erro: 'Não foi possível realizar o login.' }); }
});

app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.post('/api/fotos', logged, upload.single('imagem'), async (req, res) => {
  try {
    if (req.session.user.tipo !== 'fotografo') return res.status(403).json({ erro: 'Somente fotógrafos podem publicar fotografias.' });
    if (!req.body.titulo || !req.body.local_foto || !req.file) return res.status(400).json({ erro: 'Preencha todos os campos e escolha uma imagem.' });
    const nome = '/uploads/' + req.file.filename;
    await pool.execute('INSERT INTO publicacoes (usuario_id,titulo,local_foto,imagem) VALUES (?,?,?,?)',
      [req.session.user.id, req.body.titulo, req.body.local_foto, nome]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ erro: 'Não foi possível cadastrar a fotografia.' }); }
});

app.post('/api/fotos/:id/curtir', logged, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [existing] = await pool.execute('SELECT id FROM curtidas WHERE usuario_id=? AND publicacao_id=?', [req.session.user.id, id]);
    if (existing.length) await pool.execute('DELETE FROM curtidas WHERE usuario_id=? AND publicacao_id=?', [req.session.user.id, id]);
    else await pool.execute('INSERT INTO curtidas (usuario_id,publicacao_id) VALUES (?,?)', [req.session.user.id, id]);
    const [[count]] = await pool.execute('SELECT COUNT(*) AS total FROM curtidas WHERE publicacao_id=?', [id]);
    res.json({ curtido: !existing.length, total: count.total });
  } catch (e) { res.status(500).json({ erro: 'Não foi possível atualizar a curtida.' }); }
});

app.get('/api/usuarios/:id', async (req, res) => {
  try {
    const [[u]] = await pool.execute('SELECT id,nome,tipo,foto_perfil FROM usuarios WHERE id=?', [req.params.id]);
    if (!u) return res.status(404).json({ erro: 'Fotógrafo não encontrado.' });
    const [[stats]] = await pool.execute(`SELECT COUNT(DISTINCT p.id) AS publicacoes, COUNT(c.id) AS curtidas
      FROM publicacoes p LEFT JOIN curtidas c ON c.publicacao_id=p.id WHERE p.usuario_id=?`, [u.id]);
    const [fotos] = await pool.execute('SELECT id,titulo,local_foto,imagem FROM publicacoes WHERE usuario_id=? ORDER BY criado_em DESC', [u.id]);
    res.json({ ...u, ...stats, fotos });
  } catch (e) { res.status(500).json({ erro: 'Erro ao carregar perfil.' }); }
});

app.listen(PORT, () => console.log(`SAEPVision rodando em http://localhost:${PORT}`));
